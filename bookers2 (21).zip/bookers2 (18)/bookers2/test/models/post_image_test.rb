require 'test_helper'

class PostImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
