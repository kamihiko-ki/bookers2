# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '34b0941ba5df7a86df8be534847533e7c54feb5c01355c24ec68ef2951197b51d871ccbe2b84a9d9a9ce2b49de8cc61774aa521ed090a94fdc663a4394aa1d00'